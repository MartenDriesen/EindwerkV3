[
    [
        {
            "id": "b3777519-2d2a-4f9f-b743-ed13e6d6009f",
            "image_path": "./images/Resistor.png",
            "x": 340.0,
            "y": 200.0,
            "virtual_x": 340.0,
            "virtual_y": 200.0,
            "size_x": 80,
            "size_y": 40,
            "scale_x": 80.0,
            "scale_y": 40.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                340.0,
                220.0
            ],
            "pos_pin2": [
                420.0,
                220.0
            ],
            "name": "R1",
            "properties": [
                [
                    "Ohm",
                    "2"
                ]
            ],
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Resistor"
        }
    ],
    []
]