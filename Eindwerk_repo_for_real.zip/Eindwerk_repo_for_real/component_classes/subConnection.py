from component_classes.Connection import Connection

class subConnection(Connection):
    def __init__(self):
        super().__init__()