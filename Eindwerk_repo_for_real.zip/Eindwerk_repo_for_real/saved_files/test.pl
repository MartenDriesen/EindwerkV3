[
    [
        {
            "id": "ec271e4a-e827-4a30-a37e-b306896d760c",
            "image_path": "./images/Lamp.png",
            "x": 360.0,
            "y": 280.0,
            "virtual_x": 360.0,
            "virtual_y": 280.0,
            "size_x": 40,
            "size_y": 80,
            "scale_x": 40.0,
            "scale_y": 80.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": false,
            "pos_pin1": [
                380.0,
                280.0
            ],
            "pos_pin2": [
                380.0,
                360.0
            ],
            "name": "L1",
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Lamp"
        },
        {
            "id": "67b9bd2f-5476-44c0-816f-b439f88d21bb",
            "image_path": "./images/Socket.png",
            "x": 480.0,
            "y": 260.0,
            "virtual_x": 480.0,
            "virtual_y": 260.0,
            "size_x": 40,
            "size_y": 40,
            "scale_x": 40.0,
            "scale_y": 40.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": false,
            "pos_pin1": [
                520.0,
                280.0
            ],
            "name": "J1",
            "needs_update": true,
            "pos_pin2": null,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Socket"
        },
        {
            "id": "3543b4da-a011-472f-8058-15e33948ac5e",
            "image_path": "./images/Fuse.png",
            "x": 380.0,
            "y": 200.0,
            "virtual_x": 380.0,
            "virtual_y": 200.0,
            "size_x": 80,
            "size_y": 40,
            "scale_x": 80.0,
            "scale_y": 40.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                380.0,
                220.0
            ],
            "pos_pin2": [
                460.0,
                220.0
            ],
            "name": "F1",
            "properties": [
                [
                    "Max amps",
                    0
                ]
            ],
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Fuse"
        },
        {
            "id": "2a4520cd-ae41-415c-8c9e-5b8a84a391df",
            "image_path": "./images/Resistor.png",
            "x": 300.0,
            "y": 180.0,
            "virtual_x": 300.0,
            "virtual_y": 180.0,
            "size_x": 80,
            "size_y": 40,
            "scale_x": 80.0,
            "scale_y": 40.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                300.0,
                200.0
            ],
            "pos_pin2": [
                380.0,
                200.0
            ],
            "name": "R1",
            "properties": [
                [
                    "Ohm",
                    0
                ]
            ],
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Resistor"
        },
        {
            "id": "75d3a7b8-4100-48f8-b60f-a6f7ac6c39e3",
            "image_path": "./images/Ground.png",
            "x": 460.0,
            "y": 340.0,
            "virtual_x": 460.0,
            "virtual_y": 340.0,
            "size_x": 40,
            "size_y": 40,
            "scale_x": 40.0,
            "scale_y": 40.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": false,
            "pos_pin1": [
                480.0,
                340.0
            ],
            "name": "G1",
            "needs_update": true,
            "pos_pin2": null,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Ground"
        }
    ],
    []
]