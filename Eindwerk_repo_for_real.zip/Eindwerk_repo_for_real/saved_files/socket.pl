[
    [
        {
            "id": "fc435844-0812-4694-aab6-fff132d62708",
            "image_path": "./images/Socket.png",
            "x": 360.0,
            "y": 220.0,
            "virtual_x": 360.0,
            "virtual_y": 220.0,
            "size_x": 40,
            "size_y": 40,
            "scale_x": 40.0,
            "scale_y": 40.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": false,
            "pos_pin1": [
                400.0,
                240.0
            ],
            "name": "J1",
            "needs_update": true,
            "pos_pin2": null,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Socket"
        }
    ],
    []
]