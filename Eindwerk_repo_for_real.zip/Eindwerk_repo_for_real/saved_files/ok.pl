[
    [
        {
            "id": "b59d90ee-bb53-42a9-9ab3-a098aa91559e",
            "image_path": "./images/MOSFET_N_channel_enhancement_type.png",
            "x": 560.0,
            "y": 280.0,
            "virtual_x": 560.0,
            "virtual_y": 280.0,
            "size_x": 80,
            "size_y": 80,
            "scale_x": 80.0,
            "scale_y": 80.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                620.0,
                280.0
            ],
            "pos_pin2": [
                560.0,
                340.0
            ],
            "pos_pin3": [
                620.0,
                360.0
            ],
            "name": "T1",
            "properties": [
                [
                    "Max drain-src voltage",
                    0
                ],
                [
                    "Max drain current",
                    0
                ],
                [
                    "Treshold Voltage",
                    0
                ]
            ],
            "needs_update": true,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "MOSFET_N_Enhance"
        },
        {
            "id": "eaa22a53-0d79-403c-9ed3-1f9c12d7d922",
            "image_path": "./images/Potentiometer.png",
            "x": 340.0,
            "y": 280.0,
            "virtual_x": 340.0,
            "virtual_y": 280.0,
            "size_x": 80,
            "size_y": 60,
            "scale_x": 80.0,
            "scale_y": 60.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                340.0,
                300.0
            ],
            "pos_pin2": [
                420.0,
                300.0
            ],
            "pos_pin3": [
                380.0,
                340.0
            ],
            "name": "R1",
            "properties": [
                [
                    "ohm",
                    "10000"
                ]
            ],
            "needs_update": true,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Potentiometer"
        },
        {
            "id": "4efc3839-511c-455f-a4c7-e1532f50f797",
            "image_path": "./images/DC_motor.png",
            "x": 600.0,
            "y": 400.0,
            "virtual_x": 600.0,
            "virtual_y": 400.0,
            "size_x": 40,
            "size_y": 80,
            "scale_x": 40.0,
            "scale_y": 80.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                620.0,
                400.0
            ],
            "pos_pin2": [
                620.0,
                480.0
            ],
            "name": "V1",
            "properties": [
                [
                    "rpm",
                    "60"
                ]
            ],
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "DC_Motor"
        },
        {
            "id": "9f4e6182-a550-481d-be10-cc967da5eacf",
            "image_path": "./images/Battery.png",
            "x": 300.0,
            "y": 440.0,
            "virtual_x": 300.0,
            "virtual_y": 440.0,
            "size_x": 60,
            "size_y": 80,
            "scale_x": 60.0,
            "scale_y": 80.0,
            "rotation": 180,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                360.0,
                480.0
            ],
            "pos_pin2": [
                300.0,
                480.0
            ],
            "name": "V1",
            "properties": [
                [
                    "Voltage",
                    "9"
                ]
            ],
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Battery"
        },
        {
            "id": "97180917-02bc-4e47-b4c2-c98925dc4474",
            "image_path": "./images/Resistor.png",
            "x": 460.0,
            "y": 380.0,
            "virtual_x": 460.0,
            "virtual_y": 380.0,
            "size_x": 80,
            "size_y": 40,
            "scale_x": 80.0,
            "scale_y": 40.0,
            "rotation": 180,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                540.0,
                400.0
            ],
            "pos_pin2": [
                460.0,
                400.0
            ],
            "name": "R2",
            "properties": [
                [
                    "Ohm",
                    "220"
                ]
            ],
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Resistor"
        },
        {
            "id": "6f3f4d9a-02d0-40b1-841a-1cb8b064c0b6",
            "image_path": "./images/Led.png",
            "x": 520.0,
            "y": 420.0,
            "virtual_x": 520.0,
            "virtual_y": 420.0,
            "size_x": 60,
            "size_y": 40,
            "scale_x": 60.0,
            "scale_y": 40.0,
            "rotation": 270,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                540.0,
                420.0
            ],
            "pos_pin2": [
                540.0,
                480.0
            ],
            "name": "D1",
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "LED"
        },
        {
            "id": "534529d3-3a6e-4ea4-b5fd-16350bac5cfb",
            "image_path": "./images/MOSFET_N_channel_enhancement_type.png",
            "x": 1020.0,
            "y": 320.0,
            "virtual_x": 1020.0,
            "virtual_y": 320.0,
            "size_x": 80,
            "size_y": 80,
            "scale_x": 80.0,
            "scale_y": 80.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                1080.0,
                320.0
            ],
            "pos_pin2": [
                1020.0,
                380.0
            ],
            "pos_pin3": [
                1080.0,
                400.0
            ],
            "name": "T2",
            "properties": [
                [
                    "Max drain-src voltage",
                    0
                ],
                [
                    "Max drain current",
                    0
                ],
                [
                    "Treshold Voltage",
                    0
                ]
            ],
            "needs_update": true,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "MOSFET_N_Enhance"
        },
        {
            "id": "1e68a065-5820-4aaa-b951-b30ffe8c0a00",
            "image_path": "./images/Potentiometer.png",
            "x": 800.0,
            "y": 320.0,
            "virtual_x": 800.0,
            "virtual_y": 320.0,
            "size_x": 80,
            "size_y": 60,
            "scale_x": 80.0,
            "scale_y": 60.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                800.0,
                340.0
            ],
            "pos_pin2": [
                880.0,
                340.0
            ],
            "pos_pin3": [
                840.0,
                380.0
            ],
            "name": "R3",
            "properties": [
                [
                    "ohm",
                    "10000"
                ]
            ],
            "needs_update": true,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Potentiometer"
        },
        {
            "id": "b584b120-91ec-42f8-ae3a-8646a923d4db",
            "image_path": "./images/DC_motor.png",
            "x": 1060.0,
            "y": 440.0,
            "virtual_x": 1060.0,
            "virtual_y": 440.0,
            "size_x": 40,
            "size_y": 80,
            "scale_x": 40.0,
            "scale_y": 80.0,
            "rotation": 0,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                1080.0,
                440.0
            ],
            "pos_pin2": [
                1080.0,
                520.0
            ],
            "name": "V2",
            "properties": [
                [
                    "rpm",
                    "60"
                ]
            ],
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "DC_Motor"
        },
        {
            "id": "076cc14a-095c-4d81-9eed-3f80e26b3b50",
            "image_path": "./images/Battery.png",
            "x": 760.0,
            "y": 480.0,
            "virtual_x": 760.0,
            "virtual_y": 480.0,
            "size_x": 60,
            "size_y": 80,
            "scale_x": 60.0,
            "scale_y": 80.0,
            "rotation": 180,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                820.0,
                520.0
            ],
            "pos_pin2": [
                760.0,
                520.0
            ],
            "name": "V2",
            "properties": [
                [
                    "Voltage",
                    "9"
                ]
            ],
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Battery"
        },
        {
            "id": "a2ed7942-944a-402b-8a16-a93847074293",
            "image_path": "./images/Resistor.png",
            "x": 920.0,
            "y": 420.0,
            "virtual_x": 920.0,
            "virtual_y": 420.0,
            "size_x": 80,
            "size_y": 40,
            "scale_x": 80.0,
            "scale_y": 40.0,
            "rotation": 180,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                1000.0,
                440.0
            ],
            "pos_pin2": [
                920.0,
                440.0
            ],
            "name": "R4",
            "properties": [
                [
                    "Ohm",
                    "220"
                ]
            ],
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "Resistor"
        },
        {
            "id": "0dd1360a-91ff-46bd-89b0-5638b22545d3",
            "image_path": "./images/Led.png",
            "x": 980.0,
            "y": 460.0,
            "virtual_x": 980.0,
            "virtual_y": 460.0,
            "size_x": 60,
            "size_y": 40,
            "scale_x": 60.0,
            "scale_y": 40.0,
            "rotation": 270,
            "color": [
                0,
                0,
                0
            ],
            "edited": true,
            "pos_pin1": [
                1000.0,
                460.0
            ],
            "pos_pin2": [
                1000.0,
                520.0
            ],
            "name": "D2",
            "needs_update": true,
            "pos_pin3": null,
            "pos_pin4": null,
            "pos_pin5": null,
            "pos_pin6": null,
            "class_name": "LED"
        }
    ],
    [
        {
            "id": "1a94cb4d-a043-4233-8cdf-05e90248f79d",
            "start_pos": [
                300,
                300
            ],
            "end_pos": [
                340,
                300
            ],
            "virtual_start_pos": [
                300.0,
                300.0
            ],
            "virtual_end_pos": [
                340.0,
                300.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection"
        },
        {
            "id": "25218f5d-28e1-436d-8db6-b03f35af6605",
            "start_pos": [
                380,
                340
            ],
            "end_pos": [
                560,
                340
            ],
            "virtual_start_pos": [
                380.0,
                340.0
            ],
            "virtual_end_pos": [
                560.0,
                340.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection"
        },
        {
            "id": "ad5a1e88-42c3-4aee-8ade-09f8a374a08f",
            "start_pos": [
                620,
                360
            ],
            "end_pos": [
                620,
                400
            ],
            "virtual_start_pos": [
                620.0,
                360.0
            ],
            "virtual_end_pos": [
                620.0,
                400.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection"
        },
        {
            "id": "6835488d-70c8-45aa-9b61-816317e22988",
            "start_pos": [
                420,
                300
            ],
            "end_pos": [
                420,
                480
            ],
            "virtual_start_pos": [
                420.0,
                300.0
            ],
            "virtual_end_pos": [
                420.0,
                480.0
            ],
            "color": [
                1,
                153,
                255
            ],
            "class_name": "subConnection"
        },
        {
            "id": "9ed1c116-2cda-4292-ae49-a7b0ef6160bc",
            "start_pos": [
                620,
                480
            ],
            "end_pos": [
                360,
                480
            ],
            "virtual_start_pos": [
                620.0,
                480.0
            ],
            "virtual_end_pos": [
                360.0,
                480.0
            ],
            "color": [
                1,
                153,
                255
            ],
            "class_name": "subConnection"
        },
        {
            "id": "bec4176e-c8b3-4ad9-a571-244c4db5a583",
            "start_pos": [
                300,
                300
            ],
            "end_pos": [
                300,
                480
            ],
            "virtual_start_pos": [
                300.0,
                300.0
            ],
            "virtual_end_pos": [
                300.0,
                480.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection"
        },
        {
            "id": "197fbbd4-3413-4229-b032-f427949235ae",
            "start_pos": [
                300,
                300
            ],
            "end_pos": [
                300,
                240
            ],
            "virtual_start_pos": [
                300.0,
                300.0
            ],
            "virtual_end_pos": [
                300.0,
                240.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection"
        },
        {
            "id": "1a660bd6-6f19-4e8e-b07b-9857e925a64d",
            "start_pos": [
                300,
                240
            ],
            "end_pos": [
                620,
                240
            ],
            "virtual_start_pos": [
                300.0,
                240.0
            ],
            "virtual_end_pos": [
                620.0,
                240.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection"
        },
        {
            "id": "f4a093ac-7fe8-4e7e-83de-77541a3367e5",
            "start_pos": [
                620,
                240
            ],
            "end_pos": [
                620,
                280
            ],
            "virtual_start_pos": [
                620.0,
                240.0
            ],
            "virtual_end_pos": [
                620.0,
                280.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection"
        },
        {
            "id": "828bd843-8bd2-4e35-86a8-b657c6b4eb75",
            "start_pos": [
                460,
                340
            ],
            "end_pos": [
                460,
                400
            ],
            "virtual_start_pos": [
                460.0,
                340.0
            ],
            "virtual_end_pos": [
                460.0,
                400.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection"
        },
        {
            "id": "80603271-5d05-41ab-a8d5-a24606e126c8",
            "start_pos": [
                540,
                400
            ],
            "end_pos": [
                540,
                420
            ],
            "virtual_start_pos": [
                540.0,
                400.0
            ],
            "virtual_end_pos": [
                540.0,
                420.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection"
        },
        {
            "id": "5cd5832e-da13-4986-ab81-c311c2690da9",
            "start_pos": [
                760,
                340
            ],
            "end_pos": [
                800,
                340
            ],
            "virtual_start_pos": [
                760.0,
                340.0
            ],
            "virtual_end_pos": [
                800.0,
                340.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection",
            "needs_update": true
        },
        {
            "id": "35677bb6-514f-4437-a3a9-5f6f0880ced6",
            "start_pos": [
                840,
                380
            ],
            "end_pos": [
                1020,
                380
            ],
            "virtual_start_pos": [
                840.0,
                380.0
            ],
            "virtual_end_pos": [
                1020.0,
                380.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection",
            "needs_update": true
        },
        {
            "id": "4e53e0c7-8d17-4544-88cd-80e9532e3681",
            "start_pos": [
                1080,
                400
            ],
            "end_pos": [
                1080,
                440
            ],
            "virtual_start_pos": [
                1080.0,
                400.0
            ],
            "virtual_end_pos": [
                1080.0,
                440.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection",
            "needs_update": true
        },
        {
            "id": "b4b12a94-37f3-4f04-8c04-ddf07b54cf1a",
            "start_pos": [
                880,
                340
            ],
            "end_pos": [
                880,
                520
            ],
            "virtual_start_pos": [
                880.0,
                340.0
            ],
            "virtual_end_pos": [
                880.0,
                520.0
            ],
            "color": [
                1,
                153,
                255
            ],
            "class_name": "subConnection",
            "needs_update": true
        },
        {
            "id": "889a6b26-3d42-4ce7-997b-319dcbd40474",
            "start_pos": [
                1080,
                520
            ],
            "end_pos": [
                820,
                520
            ],
            "virtual_start_pos": [
                1080.0,
                520.0
            ],
            "virtual_end_pos": [
                820.0,
                520.0
            ],
            "color": [
                1,
                153,
                255
            ],
            "class_name": "subConnection",
            "needs_update": true
        },
        {
            "id": "83fb38eb-6002-43f7-8422-be66501c659a",
            "start_pos": [
                760,
                340
            ],
            "end_pos": [
                760,
                520
            ],
            "virtual_start_pos": [
                760.0,
                340.0
            ],
            "virtual_end_pos": [
                760.0,
                520.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection",
            "needs_update": true
        },
        {
            "id": "b7bfdd55-0e57-4630-9a77-c321cbd976b6",
            "start_pos": [
                760,
                340
            ],
            "end_pos": [
                760,
                280
            ],
            "virtual_start_pos": [
                760.0,
                340.0
            ],
            "virtual_end_pos": [
                760.0,
                280.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection",
            "needs_update": true
        },
        {
            "id": "1b199576-3c6c-4927-88fb-55aa7cd02c43",
            "start_pos": [
                760,
                280
            ],
            "end_pos": [
                1080,
                280
            ],
            "virtual_start_pos": [
                760.0,
                280.0
            ],
            "virtual_end_pos": [
                1080.0,
                280.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection",
            "needs_update": true
        },
        {
            "id": "63615060-02f6-4e85-b03e-5245373d40ef",
            "start_pos": [
                1080,
                280
            ],
            "end_pos": [
                1080,
                320
            ],
            "virtual_start_pos": [
                1080.0,
                280.0
            ],
            "virtual_end_pos": [
                1080.0,
                320.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection",
            "needs_update": true
        },
        {
            "id": "8b671391-7b0a-407e-bf6d-a9a0d31a45f8",
            "start_pos": [
                920,
                380
            ],
            "end_pos": [
                920,
                440
            ],
            "virtual_start_pos": [
                920.0,
                380.0
            ],
            "virtual_end_pos": [
                920.0,
                440.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection",
            "needs_update": true
        },
        {
            "id": "9300cd44-abbb-441e-b2f8-fb8e9317ca64",
            "start_pos": [
                1000,
                440
            ],
            "end_pos": [
                1000,
                460
            ],
            "virtual_start_pos": [
                1000.0,
                440.0
            ],
            "virtual_end_pos": [
                1000.0,
                460.0
            ],
            "color": [
                255,
                0,
                0
            ],
            "class_name": "subConnection",
            "needs_update": true
        }
    ]
]